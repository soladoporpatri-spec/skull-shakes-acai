namespace SkullShakes.Api.Servicos;

public class WhatsAppServico
{
}
