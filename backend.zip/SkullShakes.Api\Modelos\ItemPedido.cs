namespace SkullShakes.Api.Modelos;

public class ItemPedido
{
}
