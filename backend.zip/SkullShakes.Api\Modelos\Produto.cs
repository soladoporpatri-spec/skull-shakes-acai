namespace SkullShakes.Api.Modelos;

public class Produto
{
}
