namespace SkullShakes.Api.DTOs;

public class PedidoRequest
{
}

public class ItemPedidoRequest
{
}
