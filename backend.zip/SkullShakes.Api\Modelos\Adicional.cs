namespace SkullShakes.Api.Modelos;

public class Adicional
{
}
