namespace SkullShakes.Api.Modelos;

public class Pedido
{
}
