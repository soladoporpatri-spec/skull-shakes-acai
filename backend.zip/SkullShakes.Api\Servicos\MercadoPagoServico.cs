namespace SkullShakes.Api.Servicos;

public class MercadoPagoServico
{
}
