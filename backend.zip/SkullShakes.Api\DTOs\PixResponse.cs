namespace SkullShakes.Api.DTOs;

public class PixResponse
{
}
