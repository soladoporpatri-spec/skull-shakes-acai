namespace SkullShakes.Api.Endpoints;

public static class CardapioEndpoints
{
    public static void MapCardapioEndpoints(this WebApplication app)
    {
    }
}
