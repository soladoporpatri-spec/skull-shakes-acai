using Microsoft.EntityFrameworkCore;
using SkullShakes.Api.Modelos;

namespace SkullShakes.Api.BancoDeDados;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
}
